import React from 'react'
import { FaHome } from 'react-icons/fa'
const SingleTour = () => {
  return (
    <div>
      this is a single tour
      <FaHome />
    </div>
  )
}

export default SingleTour
