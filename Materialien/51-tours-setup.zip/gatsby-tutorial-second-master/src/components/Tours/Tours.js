import React from 'react'
import SingleTour from './SingleTour'
const Tours = () => {
  return (
    <div>
      this is tours component
      <SingleTour />
    </div>
  )
}

export default Tours
