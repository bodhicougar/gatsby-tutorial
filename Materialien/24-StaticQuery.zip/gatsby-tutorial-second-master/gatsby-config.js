module.exports = {
  /* Your site config here */
  siteMetadata: {
    title: 'tutorial',
    description: 'just some description about our site',
    author: '@johndoe',
    data: { name: 'john', age: 25 },
  },
  plugins: [`gatsby-plugin-sass`, `gatsby-plugin-styled-components`],
}
