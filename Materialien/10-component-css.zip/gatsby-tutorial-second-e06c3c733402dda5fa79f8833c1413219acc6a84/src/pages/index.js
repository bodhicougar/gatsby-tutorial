import React from 'react'
import Layout from '../components/layout'
export default () => (
  <Layout>
    <h1>this is our home page</h1>
    <h1>another heading</h1>
    Hello world!
  </Layout>
)
