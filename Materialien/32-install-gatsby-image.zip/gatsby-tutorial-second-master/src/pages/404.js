import React from 'react'
import Layout from '../components/layout'

const Error = () => {
  return <Layout>this is our error page</Layout>
}

export default Error
