import React from 'react'
import Navbar from '../components/Navbar'
export default () => (
  <div>
    <Navbar />
    <h1>this is our home page</h1>
    Hello world!
  </div>
)
