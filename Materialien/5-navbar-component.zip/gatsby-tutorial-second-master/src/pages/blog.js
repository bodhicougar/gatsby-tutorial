import React, { Component } from 'react'

export default class blog extends Component {
  render() {
    return <div>this is our blog page</div>
  }
}
