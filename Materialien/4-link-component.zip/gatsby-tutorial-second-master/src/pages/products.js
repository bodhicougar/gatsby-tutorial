import React from 'react'

export default function products() {
  return (
    <div>
      <h1>this is products page</h1>
    </div>
  )
}
