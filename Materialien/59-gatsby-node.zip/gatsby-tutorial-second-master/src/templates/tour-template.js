import React from 'react'

const TourTemplate = props => {
  console.log(props)

  return <div>hello from tour template</div>
}

export default TourTemplate
