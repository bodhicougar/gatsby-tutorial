import React from 'react'

const Error = () => {
  return <div>this is our error page</div>
}

export default Error
