import React from 'react'

export default () => (
  <div>
    <h1>this is our home page</h1>
    Hello world!
  </div>
)
