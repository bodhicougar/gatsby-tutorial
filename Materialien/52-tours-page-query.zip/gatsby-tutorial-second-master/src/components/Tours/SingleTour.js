import React from 'react'

const SingleTour = () => {
  return <div>this is a single tour</div>
}

export default SingleTour
