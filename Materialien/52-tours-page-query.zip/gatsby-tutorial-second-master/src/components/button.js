import styled from 'styled-components'

export const Button = styled.button`
  background: green;
  color: white;
  font-size: 2rem;
  display: inline-block;
`
