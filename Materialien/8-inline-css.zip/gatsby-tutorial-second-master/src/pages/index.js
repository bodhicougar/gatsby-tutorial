import React from 'react'
import Layout from '../components/layout'
export default () => (
  <Layout>
    <h1 style={{ color: 'red', textTransform: 'capitalize' }}>
      this is our home page
    </h1>
    Hello world!
  </Layout>
)
