import React from 'react'

const TourTemplate = () => {
  return <div>hello from tour template</div>
}

export default TourTemplate
