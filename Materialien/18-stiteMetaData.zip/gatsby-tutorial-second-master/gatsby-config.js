module.exports = {
  /* Your site config here */
  siteMetadata: {
    title: 'tutorial',
    description: 'just some description about our site',
    author: '@johndoe',
    data: ['item1', 'item2'],
  },
  plugins: [`gatsby-plugin-sass`, `gatsby-plugin-styled-components`],
}
