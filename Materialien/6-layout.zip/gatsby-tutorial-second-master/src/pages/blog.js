import React, { Component } from 'react'
import Layout from '../components/layout'

export default class blog extends Component {
  render() {
    return <Layout>this is our blog page</Layout>
  }
}
