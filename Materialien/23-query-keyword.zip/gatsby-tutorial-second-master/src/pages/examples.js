import React from 'react'
import Header from '../examples/Header'
const examples = () => {
  return (
    <div>
      examples page
      <Header />
    </div>
  )
}

export default examples
