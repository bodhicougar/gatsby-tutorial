import React, { Component } from 'react'
import Layout from '../components/layout'

export default class blog extends Component {
  render() {
    return (
      <Layout>
        <h1>this is our blog page</h1>
      </Layout>
    )
  }
}
