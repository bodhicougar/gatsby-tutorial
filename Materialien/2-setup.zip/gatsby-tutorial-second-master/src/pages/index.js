import React from 'react'

export default () => (
  <div>
    <img src="image.jpeg" />
    Hello world!
  </div>
)
