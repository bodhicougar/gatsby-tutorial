import React from 'react'
import Layout from '../components/layout'
import Images from '../components/Images'
export default function products() {
  return (
    <Layout>
      <h1>this is products page</h1>
      <Images />
    </Layout>
  )
}
