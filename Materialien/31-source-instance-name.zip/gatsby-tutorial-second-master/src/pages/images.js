import React from 'react'
import Layout from '../components/layout'

const images = () => {
  return <Layout>this is images page</Layout>
}

export default images
